package tests;

import java.util.List;

import us.lsi.common.Files2;

public class Test {

	public static void main(String[] args) {
		Ejercicio1("ficheros/PI1Ej1DatosEntrada.txt");
		
		Ejercicio2("ficheros/PI1Ej2DatosEntrada.txt");
		
		Ejercicio3("ficheros/PI1Ej3DatosEntrada1A.txt",
				"ficheros/PI1Ej3DatosEntrada1B.txt");
		Ejercicio3("ficheros/PI1Ej3DatosEntrada2A.txt",
				"ficheros/PI1Ej3DatosEntrada2B.txt");
		Ejercicio3("ficheros/PI1Ej3DatosEntrada3A.txt",
				"ficheros/PI1Ej3DatosEntrada3B.txt");
		
		Ejercicio4("ficheros/PI1Ej4DatosEntrada.txt");

	}

	private static void Ejercicio1(String fichero) {
		List<String> f = Files2.linesFromFile(fichero);
		
		for (String linea:f) {
			String[] trozo = linea.split(",");
			
			Integer a = Integer.parseInt(trozo[0].trim());
			String b = trozo[1].trim();
			Integer c = Integer.parseInt(trozo[2].trim());
			String d = trozo[3].trim();
			Integer e = Integer.parseInt(trozo[4].trim());

			System.out.println("Datos: " + linea);
			System.out.println("1) Solucion Funcional: \n" + ejercicios.Ejercicio1.ejercicio1(a,b,c,d,e));
			System.out.println("2) Solucion Iterativa: \n" + ejercicios.Ejercicio1.solucionIterativa(a,b,c,d,e));
			System.out.println("3) Solucion Recursiva Final: \n" + ejercicios.Ejercicio1.solucionRecursivaFinal(a,b,c,d,e));
			System.out.println("-------------------------------------------------------------------------------------------");
		}
	}

	private static void Ejercicio2(String fichero) {
		List<String> f = Files2.linesFromFile(fichero);
		
		for (String linea:f) {
			String[] trozo = linea.split(",");
			
			Integer a = Integer.parseInt(trozo[0].trim());
			Integer b = Integer.parseInt(trozo[1].trim());	
			String s = trozo[2].trim();
			
			System.out.println("Datos: " + linea);
			System.out.println("1) Solucion Iterativa: \n" + ejercicios.Ejercicio2.solucionIterativaWhile(a, b, s));
			System.out.println("2) Solucion Recursiva NO Final: \n" + ejercicios.Ejercicio2.solucionRecursivaNoFinal(a,b,s));
			System.out.println("3) Solucion Recursiva Final: \n" + ejercicios.Ejercicio2.solucionRecursivaFinal(a,b,s));
			System.out.println("4) Solucion Funcional: \n" + ejercicios.Ejercicio2.solucionFuncional(a,b,s));
			
			System.out.println("-------------------------------------------------------------------------------------------");

			
		}
	}

	private static void Ejercicio3(String f1, String f2) {
		System.out.println("Solucion Iterativa :      "+ejercicios.Ejercicio3.Ejercicio3Iterativo(f1,f2));
		System.out.println("Solucion Recursiva Final :"+ejercicios.Ejercicio3.Ejercicio3RecursivoFinal(f1,f2));
		System.out.println("Solucion Funcional :      "+ejercicios.Ejercicio3.Ejercicio3Funcional(f1,f2));
		System.out.println("-------------------------------------------------------------------------------------------");
	}
	
	private static void Ejercicio4(String fichero) {
		List<String> f = Files2.linesFromFile(fichero);
		
		for (String linea:f) {
			String[] trozo = linea.split(",");
			
			Integer a = Integer.parseInt(trozo[0].trim());
			Integer b = Integer.parseInt(trozo[1].trim());
			Integer c = Integer.parseInt(trozo[2].trim());
			
			System.out.println("Datos: " + linea);
			System.out.println("1) Solucion Recursiva Sin Memoria: \n" + ejercicios.Ejercicio4.solucionRecursivaSinMem(a,b,c));
			System.out.println("2) Solucion Recursiva Con Memoria: \n" + ejercicios.Ejercicio4.solucionRecursivaConMem(a,b,c));
			System.out.println("3) Solucion Iterativa: \n" + ejercicios.Ejercicio4.solucionIterativa(a, b, c));
			
			System.out.println("-------------------------------------------------------------------------------------------");
		}
		
	}

}

