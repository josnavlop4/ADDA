package ejercicios;

import java.util.*;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class Ejercicio1 {
	
	public static Map<Integer,List<String>> ejercicio1 (Integer varA, String varB, Integer varC, String varD, Integer varE) {
		 UnaryOperator<EnteroCadena> nx = elem -> 
		 		{
		 			return EnteroCadena.of(elem.a()+2,	
		 					elem.a()%3==0?
		 					elem.s()+elem.a().toString():
		 					elem.s().substring(elem.a()%elem.s().length()));
		 		};	
		return Stream.iterate(EnteroCadena.of(varA,varB), elem -> elem.a() < varC, nx)
					 	.map(elem -> elem.s()+varD)
					 	.filter(nom -> nom.length() < varE)
					 	.collect(Collectors.groupingBy(String::length));
	}
	 
	public static record EnteroCadena(Integer a,String s) {
			public static EnteroCadena of (Integer a, String s) {
				return new EnteroCadena(a,s);
			}
	}

	public static Map<Integer, List<String>> solucionIterativa(Integer varA, String varB, Integer varC, String varD, Integer varE) {
		Map<Integer,List<String>> ac = new HashMap<>();
		List<String> r;
		while(varA<varC) {
			String en=varB+varD;
			
			varB = varA%3==0?varB+varA.toString():varB.substring(varA%varB.length());
			varA+=2;
			
			if(en.length()<varE) {
				Integer clave = en.length();
				if(ac.containsKey(clave)) {
					r = ac.get(clave);
				}else {
					r = new ArrayList<>();
					ac.put(clave, r);
				}
				r.add(en);
			}
			
		}
		
		return ac;
		
	}

	public static Map<Integer, List<String>> solucionRecursivaFinal(Integer a, String b, Integer c, String d, Integer e) {
		Map<Integer,List<String>> ac = new HashMap<>();
		ac = solucionRecursivaFinal(ac,a,b,c,d,e);
		return ac;
	}

	private static Map<Integer, List<String>> solucionRecursivaFinal(Map<Integer, List<String>> ac, Integer varA, String varB, Integer varC, 
			String varD, Integer varE) {
		
		List<String> r;
		if (varA<varC) {
			String en=varB+varD;
			
			varB = varA%3==0?varB+varA.toString():varB.substring(varA%varB.length());
			varA+=2;
			
			if(en.length()<varE) {
				Integer clave = en.length();
				if(ac.containsKey(clave)) {
					r = ac.get(clave);
				}else {
					r = new ArrayList<>();
					ac.put(clave, r);
				}
				r.add(en);
				ac = solucionRecursivaFinal(ac,varA,varB,varC,varD,varE);
				
			}
			
		}
		return ac;
	}

}
