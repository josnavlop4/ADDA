	package ejercicios;

import java.util.HashMap;
import java.util.Map;

import us.lsi.common.IntTrio;

public class Ejercicio4 {

	public static String solucionRecursivaSinMem(Integer a, Integer b, Integer c) {
		String ac = null;
		if ((a<2&&b<=2)||c<2) {
			ac="("+a.toString()+"+"+b.toString()+"+"+c.toString()+")";
		}else if (a<3||(b<3&&c<=3)) {
			ac="("+a.toString()+"-"+b.toString()+"-"+c.toString()+")";
		}else {
			if (b%a==0&&(a%2==0||b%3==0)) {
				ac="("+solucionRecursivaSinMem(a-1, b/a,c-1)+"*"+solucionRecursivaSinMem(a-2, b/2,c/2)+")";
			}else {
				ac="("+solucionRecursivaSinMem(a/2, b-2,c/2)+"/"+solucionRecursivaSinMem(a/3, b-1,c/3)+")";
			}
		}
		return ac;
	}

	public static String solucionRecursivaConMem(Integer a, Integer b, Integer c) {
		Map<IntTrio,String> m = new HashMap<>();
		return solucionRecursivaConMem(a,b,c,m);
	}

	private static String solucionRecursivaConMem(Integer a, Integer b, Integer c, Map<IntTrio, String> m) {
		String ac="";
		IntTrio key = IntTrio.of(a,b,c);
		if (m.containsKey(key)) {
			ac = m.get(key);
		}else {
			if ((a<2&&b<=2)||c<2) {
				ac="("+a.toString()+"+"+b.toString()+"+"+c.toString()+")";
			}else if (a<3||(b<3&&c<=3)) {
				ac="("+a.toString()+"-"+b.toString()+"-"+c.toString()+")";
			}else {
				if (b%a==0&&(a%2==0||b%3==0)) {
					ac="("+solucionRecursivaConMem(a-1, b/a,c-1,m)+"*"+solucionRecursivaConMem(a-2, b/2,c/2,m)+")";
				}else {
					ac="("+solucionRecursivaConMem(a/2, b-2,c/2,m)+"/"+solucionRecursivaConMem(a/3, b-1,c/3,m)+")";
				}
			}
			m.put(IntTrio.of(a, b, c), ac);	
		}
		return ac;
	}
	
	

	public static String solucionIterativa(Integer a, Integer b, Integer c) {
		Map<IntTrio,String> m = new HashMap<>();
		String ac = "";
		
		for (Integer i = 0;i<=a;i++) {
			for (Integer j= 0;j<=b;j++) {
				for (Integer k=0;k<=c;k++) {
					if ((i<2&&j<=2)||k<2) {
						ac="("+i.toString()+"+"+j.toString()+"+"+k.toString()+")";
					}else if (i<3||(j<3&&k<=3)) {
						ac="("+i.toString()+"-"+j.toString()+"-"+k.toString()+")";
					}else {
						if (j%i==0&&(i%2==0||j%3==0)) {
							ac="("+m.get(IntTrio.of(i-1, j/i,k-1))+"*"+m.get(IntTrio.of(i-2, j/2,k/2))+")";
						}else {
							ac="("+m.get(IntTrio.of(i/2, j-2,k/2))+"/"+m.get(IntTrio.of(i/3, j-1,k/3))+")";
						}
					}
					m.put(IntTrio.of(i, j, k), ac);
				}
			}
		}
		return m.get(IntTrio.of(a,b,c));
	}
	
}
