	package ejercicios;

import java.util.stream.Stream;



public class Ejercicio2 {
//	Inicializa la secuencia
//	Inicializa el acumulador
//	acumulador = llamadaRecursiva()
//	return acumulador

	public static Integer solucionRecursivaNoFinal(Integer a, Integer b, String s) {
		Integer ac = null;
		if(s.length()==0) {
			ac = a*a+b*b;
		}else if(a<2||b<2) {
			ac = s.length()+a+b;
		}else {
			if(a%s.length()<b%s.length()) {
				ac = a + b + solucionRecursivaNoFinal(a-1,b/2,s.substring(a%s.length(),b%s.length()));
			} else {
				ac = a * b + solucionRecursivaNoFinal(a/2,b-1,s.substring(b%s.length(),a%s.length()));
			}
		}
		return ac;
	}

//	if caso base
//	else --> llamadaRecursiva(next(e), funcionAcumulacion, ls)
//	return acumulador
	
	public static Integer solucionRecursivaFinal(Integer a, Integer b, String s) {
		Integer ac = 0;
		ac = solucionRecursivaFinal(a,b,s,ac);
		return ac;
	}
	
	
	private static Integer solucionRecursivaFinal(Integer a, Integer b, String s, Integer ac) {
		if(s.length()==0) {
			ac = a * a + b * b + ac;
		}else if(a<2||b<2) {
			ac = s.length()+ a + b + ac;
		}else {
			if(a%s.length()<b%s.length()) {
				ac = solucionRecursivaFinal(a-1,b/2,s.substring(a%s.length(),b%s.length()),a+b+ac);
			} else {
				ac = solucionRecursivaFinal(a/2,b-1,s.substring(b%s.length(),a%s.length()),a*b+ac);
			}
		}
		return ac;
		
	}

//	Inicializar la secuencia
//	Inicializar el acumulador
//	Abrir bucle while
//		Función de acumulación
//		next(elemento)
//	return acumulador
	
	public static Integer solucionIterativaWhile(Integer a, Integer b, String s) {		
		Integer ac = 0;
		Integer res = null;
		
		while(!((s.length()==0)||(a<2||b<2))) {
			if(a%s.length()<b%s.length()) {
				ac = a+b+ac;
				s = s.substring(a%s.length(),b%s.length()); 
				a--;
				b/=2; 
			}else {
				ac = a*b+ac;
				s = s.substring(b%s.length(),a%s.length());
				a/=2;
				b--;
			}
		}
		if(s.length()==0) {
			res = a * a + b * b + ac;
		} else if(a<2||b<2) {
			res = s.length()+ a + b + ac;
		}
		return res;
	}
	
	public static record Tupla(Integer ac,Integer a,Integer b, String s) {
		public static Tupla of (Integer ac, Integer a, Integer b, String s) {
			return new Tupla(ac,a,b,s);
		}
		public static Tupla first(Integer a, Integer b, String s) {
			//valor inicial de la secuencia
			return of(0,a,b,s);
		}
		public Tupla next() { 
			//Siguiente elemento
			Tupla nx = null;
			if(a%s.length()<b%s.length()) {
				nx = of (a+b+ac,a-1,b/2,s.substring(a%s.length(),b%s.length()));
			} else {
				nx = of (a*b+ac,a/2,b-1,s.substring(b%s.length(),a%s.length()));
			}
			return nx;
		}
		public Boolean isBaseCase() {
			return (s.length()==0)||(a<2||b<2);
		}
	}
	public static Integer solucionFuncional(Integer a, Integer b, String s) {
		Tupla elementoFinal = Stream.iterate(Tupla.first(a,b,s), elem->elem.next())
				.filter(elem->elem.isBaseCase())
				.findFirst()
				.get();
		
		Integer res = 0;
		if (elementoFinal.s.length() == 0) {
			res = elementoFinal.a * elementoFinal.a + elementoFinal.b * elementoFinal.b + elementoFinal.ac;
		}else if (elementoFinal.a<2||elementoFinal.b<2) {
			res = elementoFinal.s.length() + elementoFinal.a + elementoFinal.b + elementoFinal.ac;
		}
		return res;
	}
	
	

}
