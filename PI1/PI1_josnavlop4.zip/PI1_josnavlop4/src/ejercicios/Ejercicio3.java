package ejercicios;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import us.lsi.geometria.Punto2D;
import us.lsi.geometria.Punto2D.Cuadrante;
import us.lsi.streams.Stream2;

public class Ejercicio3 {
	
	public static List<Punto2D> Ejercicio3Iterativo (String f1,String f2){
		List<Punto2D> ls = new ArrayList<>();
		
		Iterator<String> it1 = Stream2.file(f1).iterator();
		Iterator<String> it2 = Stream2.file(f2).iterator();
		
		Punto2D p1 = null;
		Punto2D p2 = null;
		
		p1 = next(it1,p1);
		p2 = next(it2,p2);
		
		while (p1 != null || p2 != null) {
			if (p2 == null || (p1 != null && p1.compareTo(p2) <= 0)) {
              	ls.add(p1);
              	p1 = next(it1,p1);
            } else if (p2 != null){
              	ls.add(p2);
              	p2 = next(it2,p2);
            }
		}
		return ls;
	} 
	
	public static Punto2D parse(Iterator<String> it) {
		String [] v=null;
        if (it.hasNext()) {
            v=it.next().split(",");
            return Punto2D.of(Double.valueOf(v[0]),Double.valueOf(v[1]));
        }
        return null;
    }
	
	public static Punto2D next(Iterator<String> it,Punto2D p) {
//		Retorna el siguiente punto si cumple las condiciones
		while(it.hasNext()) {
			p=parse(it);
			if(esPrimOTerCuadrant(p)) {
				return p;
			}
		}
		return null;
	}
	
	public static Boolean esPrimOTerCuadrant(Punto2D p) {
		return p.getCuadrante().equals(Cuadrante.PRIMER_CUADRANTE)||p.getCuadrante().equals(Cuadrante.TERCER_CUADRANTE);
	}
	
	public static List<Punto2D> Ejercicio3RecursivoFinal (String f1,String f2){
  		List<Punto2D> ac = new ArrayList<>();
  		Iterator<String> it1 = Stream2.file(f1).iterator();
		Iterator<String> it2 = Stream2.file(f2).iterator(); 
		
		Punto2D p1 = null;
		Punto2D p2 = null;
		p1 = next(it1,p1);
		p2 = next(it2,p2);
		
  		ac = Ejercicio3RecursivoFinal(it1,it2,p1,p2,ac);
        return ac;
	}

	private static List<Punto2D> Ejercicio3RecursivoFinal(Iterator<String> it1,Iterator<String> it2,Punto2D p1,Punto2D p2,
			List<Punto2D> ac) {
		List<Punto2D> res = new ArrayList<>();
		
		if (!(p1 != null || p2 != null)) {
            res = ac;
        } else {
        	if (p2 == null || (p1 != null && p1.compareTo(p2) <= 0)) {
              	ac.add(p1);
              	p1 = next(it1,p1);
            } else if (p2 != null){
              	ac.add(p2);
              	p2 = next(it2,p2);
            }
        	res = Ejercicio3RecursivoFinal(it1,it2,p1,p2,ac);
        }
		return res;
	}
	
	public record RecordEjercicio3(Iterator<String> it1, Iterator<String> it2, Punto2D p1,Punto2D p2,List<Punto2D> ac) {
		
		public static RecordEjercicio3 of(Iterator<String> it1, Iterator<String> it2, Punto2D p1,Punto2D p2,List<Punto2D> ac) {
			return new RecordEjercicio3 (it1, it2, p1, p2, ac);
		}
		
		public RecordEjercicio3 next2() {
			RecordEjercicio3 next=null;
			if (p2==null || (p1 != null && p1.compareTo(p2) <= 0)) {
				ac.add(p1);
				next=RecordEjercicio3.of(it1, it2, next(it1,p1), p2, ac);
			} else {
				ac.add(p2);
				next=RecordEjercicio3.of(it1, it2, p1, next(it2,p2), ac);
			}
			
			return next;
		}
		
		public Boolean isBaseCase() {
			return (!(p1 != null || p2 != null));
		}

	}
	
	public static List<Punto2D> Ejercicio3Funcional (String f1,String f2){
  		Iterator<String> it1 = Stream2.file(f1).iterator();
		Iterator<String> it2 = Stream2.file(f2).iterator(); 
		
		Punto2D p1 = null;
		Punto2D p2 = null;
		p1 = next(it1,p1);
		p2 = next(it2,p2);
		
		RecordEjercicio3 elem=Stream.iterate( RecordEjercicio3.of(it1,it2,p1,p2,new ArrayList<>()), t->t.next2())
				.filter(t->t.isBaseCase())
				.findFirst()
				.get();
		return elem.ac();
	}
}

