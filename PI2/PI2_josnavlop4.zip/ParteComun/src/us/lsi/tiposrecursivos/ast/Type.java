package us.lsi.tiposrecursivos.ast;

public enum Type {
	Int,Double,Boolean,String
}
