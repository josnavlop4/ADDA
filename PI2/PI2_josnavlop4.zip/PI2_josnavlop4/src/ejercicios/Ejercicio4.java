package ejercicios;

import java.util.ArrayList;
import java.util.List;

import us.lsi.common.Pair;
import us.lsi.tiposrecursivos.BinaryTree;
import us.lsi.tiposrecursivos.BinaryTree.BEmpty;
import us.lsi.tiposrecursivos.BinaryTree.BLeaf;
import us.lsi.tiposrecursivos.BinaryTree.BTree;
import us.lsi.tiposrecursivos.Tree;
import us.lsi.tiposrecursivos.Tree.TEmpty;
import us.lsi.tiposrecursivos.Tree.TLeaf;
import us.lsi.tiposrecursivos.Tree.TNary;

public class Ejercicio4 {
	
	private static Long nVocales(String s) {
		Long b = 0L;
		List<Character> ls = new ArrayList<>();
		ls.add('a');ls.add('e');ls.add('i');ls.add('o');ls.add('u');
		for (int i = 0; i<s.length();i++) {
			Character a = s.charAt(i);
			if (ls.contains(a)) {
				b++;
			}
		}
		return b;
	}
	
	public static Boolean solucionBinaria(BinaryTree<String> tree) {
		return solucionBinariaRec(tree).second();
	}
	
	private static Pair<Long, Boolean> solucionBinariaRec(BinaryTree<String> tree) {
		return switch(tree) {
			case BEmpty<String> t->Pair.of(0L, true);
			case BLeaf<String> t->Pair.of(nVocales(t.label()),true);
			case BTree<String> t->{
				Pair<Long, Boolean> r = solucionBinariaRec(t.right());
				Pair<Long, Boolean> l = solucionBinariaRec(t.left());
				yield Pair.of(l.first() + r.first(), l.second() && r.second() && l.first()==r.first());
			}
		};
	}
	    
	public static Boolean solucionNaria(Tree<String> tree) {
	    return solucionNariaRec(tree).second();    
	}
	
	private static Pair<Long, Boolean> solucionNariaRec(Tree<String> tree){
		return switch(tree) {
			case TEmpty<String> t->Pair.of(0L, true);
			case TLeaf<String> t->Pair.of(nVocales(t.label()),true);
			case TNary<String> t->{
				yield Pair.of(t.elements().stream()
								.map(x->solucionNariaRec(x))
								.map(x->x.first())
								.reduce((x,y)->x+y)
								.get(),
							  t.elements().stream()
							  	.map(x->solucionNariaRec(x))
							  	.reduce((x,y)->Pair.of(x.first(),x.first()==y.first()&&x.second()&&y.second()))
							  	.get()
							  	.second());
		}
		};
	}
}
