package ejercicios;

import java.math.BigInteger;

public class Ejercicio1 {
	
		public static Double factorialR_Double(int n) {
			Double r;
			if (n == 0) {
				r = 1.0;
			} else {
				r = factorialR_Double(n - 1) * n;
			}
			return r;
		}

		public static Double factorialIt_Double(int n) {
			Double a = 1.0;
			while (n != 0) {
				a = a * n; 
				n = n - 1;
			}
			return a;
		}
		
		public static BigInteger factorialR_BigInteger(int n) {
			BigInteger r;
			if (n == 0) {
				r = BigInteger.ONE;
			} else {
				r = factorialR_BigInteger(n - 1).multiply(BigInteger.valueOf(n));
			}
			return r;
		}

		public static BigInteger factorialIt_BigInteger(int n) {
			BigInteger a = BigInteger.ONE;
			while (n != 0) {
				a= a.multiply(BigInteger.valueOf(n));
				n = n - 1;
			}
			return a;
		}
}
