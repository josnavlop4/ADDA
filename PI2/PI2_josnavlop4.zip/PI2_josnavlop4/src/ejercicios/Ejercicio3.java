package ejercicios;

import java.util.ArrayList;
import java.util.List;

import us.lsi.tiposrecursivos.BinaryTree;
import us.lsi.tiposrecursivos.BinaryTree.BEmpty;
import us.lsi.tiposrecursivos.BinaryTree.BLeaf;
import us.lsi.tiposrecursivos.BinaryTree.BTree;
import us.lsi.tiposrecursivos.Tree;
import us.lsi.tiposrecursivos.Tree.TEmpty;
import us.lsi.tiposrecursivos.Tree.TLeaf;
import us.lsi.tiposrecursivos.Tree.TNary;

public class Ejercicio3 {
	
	public static List<String> solucionBinaria(BinaryTree<Character> tree, Character chars) {
		List<String> res = new ArrayList<>();
		return solucionBinaria(tree,chars,res,"");
	}

	private static List<String> solucionBinaria(BinaryTree<Character> tree, Character chars, List<String> res, String cad) {
		switch(tree) {
		case BEmpty<Character> t->{
			break;
		}
		case BLeaf<Character> t->{
			cad = cad + t.label();
			if (!cad.contains(chars.toString())) {
				res.add(cad);
			}
			break;
		}
		case BTree<Character> t->{
			solucionBinaria(t.left(),chars,res,cad + t.label());
			solucionBinaria(t.right(),chars,res,cad + t.label());
			break;
		}
		};
		return res;
	}

	public static List<String> solucionNaria(Tree<Character> tree, Character chars) {
		List<String> res = new ArrayList<>();
		return solucionNaria(tree,chars,res,"");
	}
	
	private static List<String> solucionNaria(Tree<Character> tree, Character chars,List<String> res, String cad){
		return switch(tree) {
		case TEmpty<Character> t->res;
		case TLeaf<Character> t->{
			cad = cad + t.label();
			if (!cad.contains(chars.toString())) {
				res.add(cad);
			}
			yield res;
		}
		case TNary<Character> t->{
			String cad1 = cad+t.label();
			t.elements().forEach(tc ->solucionNaria(tc,chars,res, cad1));
			yield res;
		}
		};
	}


}
