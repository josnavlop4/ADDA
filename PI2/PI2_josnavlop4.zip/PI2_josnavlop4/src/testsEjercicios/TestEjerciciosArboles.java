package testsEjercicios;

import java.util.List;

import ejercicios.Ejercicio3;
import ejercicios.Ejercicio4;
import us.lsi.common.Files2;
import us.lsi.common.Pair;
import us.lsi.common.Preconditions;
import us.lsi.tiposrecursivos.BinaryTree;
import us.lsi.tiposrecursivos.Tree;

public class TestEjerciciosArboles {
	public static void main(String[] args) {
		testsEjercicio3();
		testsEjercicio4();
	}
	
	public static void testsEjercicio3() {
		testsEjercicio3Binario();
		testsEjercicio3Nario();
	}
	
	public static void testsEjercicio3Binario() {
		String file = "ficheros/Ejercicio3DatosEntradaBinario.txt";
		
		List<Pair<BinaryTree<Character>, Character>> inputs = Files2.streamFromFile(file).map(linea -> {
			String[] aux = linea.split("#");
			Preconditions.checkArgument(aux.length == 2);
			return Pair.of(BinaryTree.parse(aux[0], s -> s.charAt(0)), aux[1].charAt(0));
		}).toList();
		
		
		System.out.println("************** EJERCICIO 3 (Binario) *******************");
		System.out.println("------------------------------------------------------");
		
		inputs.stream().forEach(par->{
			BinaryTree<Character> tree = par.first();
			Character chars = par.second();
			
			System.out.println("Arbol:"+tree+"\t Caracter:"+ chars + "\t["+
					Ejercicio3.solucionBinaria(tree,chars)+"]");
			
		System.out.println("------------------------------------------------------");
		});
	}
	
	public static void testsEjercicio3Nario() {
		String file = "ficheros/Ejercicio3DatosEntradaNario.txt";
		
		List<Pair<Tree<Character>, Character>> inputs = Files2.streamFromFile(file).map(linea -> {
			String[] aux = linea.split("#");
			Preconditions.checkArgument(aux.length == 2);
			return Pair.of(Tree.parse(aux[0], s -> s.charAt(0)), aux[1].charAt(0));
		}).toList();
		
		System.out.println("************** EJERCICIO 3 (Nario) *******************");
		System.out.println("------------------------------------------------------");
		
		inputs.stream().forEach(par->{
			Tree<Character> tree = par.first();
			Character chars = par.second();
			
			System.out.println("Arbol: "+tree+"\t Caracter: "+ chars + "\t["+
					Ejercicio3.solucionNaria(tree,chars)+"]");
			
		System.out.println("------------------------------------------------------");
		});
	}
	
	public static void testsEjercicio4() {
		testsEjercicio4Binario();
		testsEjercicio4Nario();
	}
	
	public static void testsEjercicio4Binario() {
		String file = "ficheros/Ejercicio4DatosEntradaBinario.txt";

		List<BinaryTree<String>> inputs = Files2.streamFromFile(file)
				.map(linea -> BinaryTree.parse(linea)).toList();

		System.out.println("**************************      EJERCICIO 4 (Binario)        ***************************");
		System.out.println("----------------------------------------------------------------------------------------");
		
		inputs.stream().forEach(x -> System.out.println(x + ":" + Ejercicio4.solucionBinaria(x)));
		System.out.println("----------------------------------------------------------------------------------------");
	}
	
	public static void testsEjercicio4Nario() {
		String file = "ficheros/Ejercicio4DatosEntradaNario.txt";

		List<Tree<String>> inputs = Files2.streamFromFile(file)
				.map(linea -> Tree.parse(linea)).toList();

		System.out.println("**************************        EJERCICIO 4 (Nario)        ***************************");
		System.out.println("----------------------------------------------------------------------------------------");

		inputs.stream().forEach(x -> System.out.println(x+ ":" + Ejercicio4.solucionNaria(x)));
		System.out.println("----------------------------------------------------------------------------------------");
	}

}
