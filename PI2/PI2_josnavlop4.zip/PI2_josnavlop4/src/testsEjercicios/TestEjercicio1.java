package testsEjercicios;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import ejercicios.Ejercicio1;
import us.lsi.common.Pair;
import us.lsi.common.Trio;
import us.lsi.curvefitting.DataCurveFitting;
import utils.GraficosAjuste;
import utils.Resultados;
import utils.TipoAjuste;

public class TestEjercicio1 {

	public static void main(String[] args) {
//		generaFicherosTiempoEjecucion();
//		generaFicherosTiempoEjecucion2();
		muestraGraficas();

	}
	
	private static Integer nMin = 10; // n mínimo para el cálculo de potencia
	private static Integer nMax = 100000; // n máximo para el cálculo de potencia
	private static Integer nMaxBigInt = 5000; 
	private static Integer numSizes = 100; // número de problemas (número de potencias distintas a calcular)
	private static Integer numMediciones = 10; // número de mediciones de tiempo de cada caso (número de experimentos)
	private static Integer numIter = 50; // número de iteraciones para cada medición de tiempo
	private static Integer numIterWarmup = 1000; // número de iteraciones para warmup
	
	private static List<Trio<Function<Integer, Double>, TipoAjuste, String>> metodosDouble = 
			List.of(
					Trio.of(Ejercicio1::factorialIt_Double, TipoAjuste.POWERANB ,"factorialIt_Double"),
					Trio.of(Ejercicio1::factorialR_Double, TipoAjuste.POWERANB, "factorialR_Double")
			);
	
	private static List<Trio<Function<Integer, BigInteger>, TipoAjuste, String>> metodosBigInteger = 
			List.of( 
					Trio.of(Ejercicio1::factorialIt_BigInteger, TipoAjuste.POWERANB, "factorialIt_BigInteger"),
					Trio.of(Ejercicio1::factorialR_BigInteger, TipoAjuste.POWERANB, "factorialR_BigInteger")
			);
	
	public static void generaFicherosTiempoEjecucion() {
		for (int i = 0; i < metodosDouble.size(); i++) { 	
			String ficheroSalida = String.format("ficheros/Tiempos%s.csv", metodosDouble.get(i).third());
			testTiemposEjecucion(nMin, nMax, metodosDouble.get(i).first(), ficheroSalida);
		}
	}
	
	public static void generaFicherosTiempoEjecucion2() {
		for (int i = 0; i < metodosBigInteger.size(); i++) { 	
			String ficheroSalida = String.format("ficheros/Tiempos%s.csv", metodosBigInteger.get(i).third());
			testTiemposEjecucion2(nMin, nMaxBigInt, metodosBigInteger.get(i).first(), ficheroSalida);
		}
	}
	
	
	public static <E> void muestraGraficasMetodos(List<Trio<Function<E, Number>, TipoAjuste, String>> metodos, List<String> ficherosSalida, List<String> labels) {
		for (int i=0; i<metodos.size(); i++) { 
			
			String ficheroSalida = String.format("ficheros/Tiempos%s.csv",
					metodos.get(i).third());
			ficherosSalida.add(ficheroSalida);
			String label = metodos.get(i).third();
			System.out.println(label);

			TipoAjuste tipoAjuste = metodos.get(i).second();
			GraficosAjuste.show(ficheroSalida, tipoAjuste, label);	
			
			Pair<Function<Double, Double>, String> parCurve = GraficosAjuste.fitCurve(
					DataCurveFitting.points(ficheroSalida), tipoAjuste);
			String ajusteString = parCurve.second();
			labels.add(String.format("%s     %s", label, ajusteString));
		}
	}
	
	public static void muestraGraficas() {
		
		List<String> ficherosSalida = new ArrayList<>();
		List<String> labels = new ArrayList<>();
		
		for (int i = 0; i < metodosDouble.size(); i++) { 
			String ficheroSalida = String.format("ficheros/Tiempos%s.csv", metodosDouble.get(i).third());
			ficherosSalida.add(ficheroSalida);
			String label = metodosDouble.get(i).third();
			System.out.println(label);
			TipoAjuste tipoAjuste = metodosDouble.get(i).second();
			GraficosAjuste.show(ficheroSalida, tipoAjuste, label);
			Pair<Function<Double, Double>, String> parCurve = GraficosAjuste.fitCurve(DataCurveFitting.points(ficheroSalida), tipoAjuste);
			String ajusteString = parCurve.second();
			labels.add(String.format("%s     %s", label, ajusteString));
		}
		GraficosAjuste.showCombined("Factorial", ficherosSalida, labels);
		
		for (int i = 0; i < metodosBigInteger.size(); i++) { 
			String ficheroSalida = String.format("ficheros/Tiempos%s.csv", metodosBigInteger.get(i).third());
			ficherosSalida.add(ficheroSalida);
			String label = metodosBigInteger.get(i).third();
			System.out.println(label);
			TipoAjuste tipoAjuste = metodosBigInteger.get(i).second();
			GraficosAjuste.show(ficheroSalida, tipoAjuste, label);
			Pair<Function<Double, Double>, String> parCurve = GraficosAjuste.fitCurve(DataCurveFitting.points(ficheroSalida), tipoAjuste);
			String ajusteString = parCurve.second();
			labels.add(String.format("%s     %s", label, ajusteString));
		}
		GraficosAjuste.showCombined("Factorial", ficherosSalida, labels);
		
	}
	
	@SuppressWarnings("unchecked")
	public static void testTiemposEjecucion(Integer nMin, Integer nMax, Function<Integer, Double> funcion,
			String ficheroTiempos) {
			Map<Problema, Double> tiempos = new HashMap<Problema, Double>();
			Integer nMed = numMediciones; 
			for (int iter = 0; iter < nMed; iter++) {
			for (int i = 0; i < numSizes; i++) {
			Double r = Double.valueOf(nMax-nMin) / (numSizes-1);
			Integer tam = (Integer.MAX_VALUE/nMax > i) ? 
			nMin + i*(nMax - nMin) / (numSizes - 1): 
			nMin + (int) (r * i);
			Problema p = Problema.of(tam);
			warmup(funcion, 10);
			Integer nIter = numIter;
			Double[] res = new Double[nIter];
			Long t0 = System.nanoTime();
			for (int z = 0; z < nIter; z++) {
			res[z] = (Double) funcion.apply(tam);
			}
			Long t1 = System.nanoTime();
			actualizaTiempos(tiempos, p, Double.valueOf(t1 - t0) / nIter);
			}
			}
			
			Resultados.toFile(tiempos.entrySet().stream()
			.map(x -> TResultD.of(x.getKey().tam(), x.getValue()))
			.map(TResultD::toString), ficheroTiempos, true);
			
			}
	
	public static void testTiemposEjecucion2(Integer nMin, Integer nMax, Function<Integer, BigInteger> funcion,
			String ficheroTiempos) {
		Map<Problema, Double> tiempos = new HashMap<Problema, Double>();
		Integer nMed = numMediciones; 
		for (int iter = 0; iter < nMed; iter++) {
			for (int i = 0; i < numSizes; i++) {
				Double r = Double.valueOf(nMaxBigInt-nMin) / (numSizes-1);
				Integer tam = (Integer.MAX_VALUE/nMaxBigInt > i) ? 
						    nMin + i*(nMaxBigInt - nMin) / (numSizes - 1): 
							nMin + (int) (r * i);
				Problema p = Problema.of(tam);
				warmup2(funcion, 10);
				Integer nIter = numIter;
				BigInteger[] res = new BigInteger[nIter];
				Long t0 = System.nanoTime();
				for (int z = 0; z < nIter; z++) {
					res[z] = funcion.apply(tam);
				}
				Long t1 = System.nanoTime();
				actualizaTiempos(tiempos, p, Double.valueOf(t1 - t0) / nIter);
			}
		}

		Resultados.toFile(tiempos.entrySet().stream()
				  .map(x -> TResultD.of(x.getKey().tam(), x.getValue()))
				  .map(TResultD::toString), ficheroTiempos, true);

	}
	
	private static void actualizaTiempos(Map<Problema, Double> tiempos, Problema p, double d) {
		if (!tiempos.containsKey(p)) {
			tiempos.put(p, d);
		} else if (tiempos.get(p) > d) {
				tiempos.put(p, d);
		}
	}
	
	
	private static void warmup(Function<Integer, Double> fact, Integer n) {
		for (int i = 0; i < numIterWarmup; i++) {
			fact.apply(n);
		}
	}
	
	private static void warmup2(Function<Integer, BigInteger> fact, Integer n) {
		for (int i = 0; i < numIterWarmup; i++) {
			fact.apply(n);
		}
	}
	
	record TResultD(Integer tam, Double t) {
		public static TResultD of(Integer tam, Double t){
			return new TResultD(tam, t);
		}
		
		public String toString() {
			return String.format("%d,%.0f", tam, t);
		}
	}
	

	record Problema(Integer tam) {
		public static Problema of(Integer tam){
			return new Problema(tam);
		}
	}
}

