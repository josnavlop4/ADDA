/**
 * @author : Jose Luis Navarro Lopez-Montenegro
 * GRUPO: IS-1A
 * FECHA: 15/05/23
 */

module miUVUS_PI5 {
	requires transitive grafos;
}