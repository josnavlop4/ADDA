package tests;

import org.jgrapht.Graph;

import datos.Ciudad;
import datos.Transporte;
import ejercicios.Ejercicio2;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class TestEjercicio2 {
	
	public static void main(String[] args) {
		testEjercicio2("PI3E2_DatosEntrada");

	}

	private static void testEjercicio2(String file) {
		
		Graph<Ciudad, Transporte> g = GraphsReader
				.newGraph("ficheros/" + file + ".txt",
						Ciudad::ofFormat, 
						Transporte::ofFormat, 
						Graphs2::simpleWeightedGraph);
	
		System.out.println("\nArchivo " + file + ".txt \n" + "Datos de entrada: " + g);
	
//		Para mostrar el grafo original
		GraphColors.toDot(g,"resultados/ejercicio2/" + file + "_Datos.gv",
				x->x.ciudad(), x->x.duracion().toString()+" min", //Atributos del vertice y de la arista
				v->GraphColors.color(Color.black), //Propiedades del vertice
				e->GraphColors.color(Color.black)); //Propiedades de la arista
		
		Ejercicio2.ApartadoA(g, file);
		
		Ejercicio2.ApartadoB(g, file);
		
		Ejercicio2.ApartadoC(g, file);
		
		Ejercicio2.ApartadoD(grafoApartD(file), file);
		
	}
	
	private static Graph<Ciudad,Transporte> grafoApartD (String file){
		return GraphsReader
				.newGraph("ficheros/" + file + ".txt",
						Ciudad::ofFormat, 
						Transporte::ofFormat, 
						Graphs2::simpleWeightedGraph,
						Transporte::duracion);
	}

}
