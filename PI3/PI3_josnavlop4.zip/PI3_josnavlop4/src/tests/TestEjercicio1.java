package tests;

import java.util.Map;
import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.graph.SimpleDirectedGraph;
import org.jgrapht.nio.Attribute;

import datos.Persona;
import datos.Relacion;
import ejercicios.Ejercicio1;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.colors.GraphColors.Style;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class TestEjercicio1 {

	public static void main(String[] args) {
		testEjercicio1("PI3E1A_DatosEntrada");
		testEjercicio1("PI3E1B_DatosEntrada");
	}

	public static void testEjercicio1(String file) {
		
		SimpleDirectedGraph<Persona,Relacion> dg = GraphsReader
				.newGraph("ficheros/" + file + ".txt", 
						Persona::ofFormat, 
						Relacion::ofFormat, 
						Graphs2::simpleDirectedGraph);
		
		System.out.println("\nArchivo " + file + ".txt \n" + "Datos de entrada: " + dg);
		
//		Para mostrar el grafo original
		
		GraphColors.toDot(dg,"resultados/ejercicio1/" + file + "_Datos" + ".gv",
				x->x.nombre(), x->"" , //Atributos del vertice y de la arista
				v->GraphColors.color(Color.black), //Propiedades del vertice
				e->GraphColors.color(Color.black)); //Propiedades de la arista
		
		
//		APARTADO A
		
		Ejercicio1.apartadoA (dg, file);
		
		
//		APARTADO B
		
		if (file == "PI3E1A_DatosEntrada") {
			 Persona p = Persona.of(13, "Maria", 2008, "Sevilla");
			 
			 GraphColors.toDot(dg,"resultados/ejercicio1/" + file + "apartadoB" + ".gv",
						x->x.nombre() , x->" ",
						v->colorea(p,v, Ejercicio1.apartadoB(dg, p)), 
						e->GraphColors.style(Style.solid));
				System.out.println(file + "apartadoB" + ".gv generado en " + "resultados/ejercicio1");
				
		} else {
			
			 Persona p = Persona.of(13, "Raquel", 1993, "Sevilla");
			 
			 GraphColors.toDot(dg,"resultados/ejercicio1/" + file + "apartadoB" + ".gv",
						x->x.nombre() , x->" ",
						v->colorea(p,v, Ejercicio1.apartadoB(dg, p)), 
						e->GraphColors.style(Style.solid));
				System.out.println(file + "apartadoB" + ".gv generado en " + "resultados/ejercicio1");
		}
		
//		APARTADO C
		
		Persona p1 = null;
		Persona p2 = null;
		
		if (file == "PI3E1A_DatosEntrada") {
			p1 = Persona.of(16, "Rafael", 2020, "Malaga"); 
			p2 = Persona.of(14, "Sara", 2015, "Jaen"); 
		} else {
			p1 = Persona.of(14, "Julia", 1996, "Jaen"); 
			p2 = Persona.of(6, "Angela", 1997, "Sevilla"); 
		}
		Ejercicio1.apartadoC (dg,p1,p2);
		
//		APARTADO D
		
		Ejercicio1.apartadoD(dg, file);
		
//		APARTADO E
		
		Graph<Persona,Relacion> g = GraphsReader
				.newGraph("ficheros/" + file + ".txt", 
						Persona::ofFormat, 
						Relacion::ofFormat, 
						Graphs2::simpleGraph);
		
		Ejercicio1.ApartadoE(g, file);
		
		
	}
	
	private static Map<String,Attribute> colorea (Persona p, Persona v, Set<Persona> per){
		Map<String,Attribute> res = GraphColors.color(Color.black);
		if(p.equals(v)) {
			res = GraphColors.color(Color.red);
		}else if(per.contains(v)) {
			res = GraphColors.color(Color.blue);
		}
		return res;
	}
	
	

}
