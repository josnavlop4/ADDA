package tests;



import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;


import ejercicios.Ejercicio3;
import us.lsi.colors.GraphColors;
import us.lsi.common.Files2;
import us.lsi.graphs.Graphs2;

public class TestEjercicio3 {

	public static void main(String[] args) {
		testEjercicio3("PI3E3A_DatosEntrada");
		testEjercicio3("PI3E3B_DatosEntrada");

	}

	private static void testEjercicio3(String file) {
		
		Graph<String, DefaultEdge> g = Graphs2.simpleGraph(String::new,DefaultEdge::new,false);
		
		Files2.streamFromFile("ficheros/"+file+".txt").forEach(linea->{
			String[] v = linea.split(":")[1].split(",");
			for (int i=0;i<v.length;i++) {
				String v0 = v[i].trim();
				g.addVertex(v0);
				for (int j=0;j<v.length;j++) {
					String v1 = v[j].trim();
					g.addVertex(v1);
					if(i!=j) {
						g.addEdge(v0,v1);
					}
				}
			}
		});
		
		GraphColors.toDot(g,"resultados/ejercicio3/"+file+"_inicial.gv");
		
		Ejercicio3.todosLosApartados(g, file);
	}

}
