package datos;

public record Persona(Integer id, String nombre, Integer anio, String ciudad) {
	public static Persona ofFormat(String[] v) {
		Integer id = Integer.valueOf(v[0]);
		String nombre = v[1];
		Integer anio = Integer.valueOf(v[2]);
		String ciudad = v[3];
		return Persona.of(id,nombre,anio,ciudad);
	}
	
	public static Persona of (Integer id, String nombre, Integer anio, String ciudad) {
		return new Persona(id,nombre,anio,ciudad);
	}
	
}
