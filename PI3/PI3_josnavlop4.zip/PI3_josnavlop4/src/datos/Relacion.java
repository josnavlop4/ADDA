package datos;

public record Relacion(Integer id,Integer r1, Integer r2) {
	
	private static int num = 0;
	
	public static Relacion ofFormat(String[] v) {
		Integer re1 = Integer.valueOf(v[0]);
		Integer re2 = Integer.valueOf(v[1]);
		Integer id = num;
		num++;
		return new Relacion(id,re1,re2);
	}
}
