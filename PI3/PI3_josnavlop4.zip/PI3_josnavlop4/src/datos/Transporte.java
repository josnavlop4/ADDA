package datos;

public record Transporte(Double precio, Double duracion) {
	
	public static Transporte ofFormat(String[] v) {
		Double precio = Double.valueOf(v[2].split("euros")[0]);
		Double duracion = Double.valueOf(v[3].split("min")[0]);
		return new Transporte(precio,duracion);
	}
}
