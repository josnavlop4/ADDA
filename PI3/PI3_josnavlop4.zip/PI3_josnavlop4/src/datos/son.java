package datos;

public enum son {
	HERMANOS,PRIMOS,OTROS
}
