package datos;

public record Ciudad(String ciudad, Double puntuacion) {
	
	public static Ciudad ofFormat(String[] v) {
		String ciudad=v[0];
		Double puntuacion = Double.valueOf(v[1].split("p")[0]);
		return new Ciudad(ciudad,puntuacion);
	}

}


