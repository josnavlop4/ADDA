module PI3_josnavlop4 {
	requires transitive grafos;
	requires org.jgrapht.core;
	requires org.jgrapht.io;
}