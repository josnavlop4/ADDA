package ejercicios;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.Graphs;
import org.jgrapht.alg.vertexcover.GreedyVCImpl;
import org.jgrapht.graph.SimpleDirectedGraph;

import datos.Persona;
import datos.Relacion;
import datos.son;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.colors.GraphColors.Style;
import us.lsi.graphs.views.SubGraphView;


public class Ejercicio1 {
	
//	APARTADO A
	
	public static void apartadoA (SimpleDirectedGraph<Persona,Relacion> g, String file) {
		Graph<Persona,Relacion> vista = SubGraphView.of(g,
				x->padres(g,x).size()>1?
						padres(g,x).stream().allMatch(y->y.anio().equals(padres(g,x).get(0).anio())
								&& y.ciudad().equals(padres(g,x).get(0).ciudad())):false,
						null);
		
		GraphColors.toDot(g,"resultados/ejercicio1/" + file + "apartadoA" + ".gv",
				x->x.nombre() , x->" ",
				v->GraphColors.colorIf(Color.blue, Color.black, vista.containsVertex(v)), 
				e->GraphColors.style(Style.solid));
		
		System.out.println(file + "apartadoA" + ".gv generado en " + "resultados/ejercicio1");
	}
	
	private static List<Persona> padres (SimpleDirectedGraph<Persona,Relacion> g,Persona p){
		return Graphs.predecessorListOf(g, p);
	}
	
	
//	APARTADO B
	
	public static Set<Persona> apartadoB (SimpleDirectedGraph<Persona,Relacion> g,Persona p) {
		
		Graph<Persona,Relacion> vista = SubGraphView.of(g,x->ancestros(g,x,p),null);
		return vista.vertexSet();
		
	}
	
	public static Boolean ancestros (SimpleDirectedGraph<Persona,Relacion> g,Persona p,Persona v) {
		Boolean ac = false;
		if(p.equals(v)){
			ac = true;
		} else if(Graphs.vertexHasPredecessors(g, v)) {
			List<Persona> ancestros = Graphs.predecessorListOf(g, v);
			for(int i=0;i<ancestros.size();i++) {
				ac = ancestros(g,p,ancestros.get(i));
				if(ac==true)break;
			}
		}
		return ac;
	}
	
//	APARTADO C
	
	public static void apartadoC (SimpleDirectedGraph<Persona,Relacion> g,Persona p1,Persona p2) {
		
		son s = son.OTROS;
		
		Set<Persona> abuelosP1 = abuelos(g,p1);
		Set<Persona> abuelosP2 = abuelos(g,p1);
		
		if(sonHermanos(g,p1,p2)) {
			s = son.HERMANOS;
		} else if(abuelosP1.equals(abuelosP2)) {
			s = son.PRIMOS;
		} 
		
		System.out.println(p1.nombre() + " y " + p2.nombre() + " son " + s.name());
		
	}
	
	public static Boolean sonHermanos (SimpleDirectedGraph<Persona,Relacion> g,Persona p1,Persona p2) {
		
		List<Persona> padresP1 = padres(g,p1);
		List<Persona> padresP2 = padres(g,p2);
		
		Boolean ac = false;
		for (int i = 0; i<padresP1.size(); i++) {
			if(padresP2.contains(padresP1.get(i))) {
				ac = true;
			}
		}
		return ac;
	}
	
	public static Set<Persona> abuelos (SimpleDirectedGraph<Persona,Relacion> g,Persona p){
		
		Set <Persona> abu = new HashSet<>();
		List<Persona> padres = padres(g,p);
		for (Persona per :padres) {
			List<Persona> a = Graphs.predecessorListOf(g, per);
			abu.addAll(a);
		}
		return abu;
	}
	
//	APARTADO D
	
	public static void apartadoD (SimpleDirectedGraph<Persona,Relacion> g, String file) {
		
		Graph<Persona,Relacion> vista = SubGraphView.of(g,x->disPadres(g,x),null);
		
		GraphColors.toDot(g,"resultados/ejercicio1/" + file + "apartadoD" + ".gv",
				x->x.nombre() , x->" ",
				v->GraphColors.colorIf(Color.blue, Color.black, vista.vertexSet().contains(v)), 
				e->GraphColors.style(Style.solid));
		
		System.out.println(file + "apartadoD" + ".gv generado en " + "resultados/ejercicio1");
		
	}
	
	public static Boolean disPadres (SimpleDirectedGraph<Persona,Relacion> g,Persona p) {
		
		Boolean ac = false;
		List<Persona> suc = Graphs.successorListOf(g, p);
		if (suc.size()>=2) {
			List<Persona> pad1 = Graphs.predecessorListOf(g, suc.get(0));
			for (Persona per:suc) {
				if(!Graphs.predecessorListOf(g, per).equals(pad1)) {
					ac = true;
				}
			}
		}
		return ac;	
	}
	
//	APARTADO E
	
	public static void ApartadoE (Graph<Persona,Relacion> g,String file) {
		
		GreedyVCImpl<Persona,Relacion> vCover = new GreedyVCImpl<>(g);
		Set<Persona> selected = vCover.getVertexCover();
		
		GraphColors.toDot(g,"resultados/ejercicio1/" + file + "apartadoE" + ".gv",
				x->x.nombre() , x->" ",
				v->GraphColors.colorIf(Color.blue, Color.black, selected.contains(v)), 
				e->GraphColors.style(Style.solid));
		
		System.out.println(file + "apartadoE" + ".gv generado en " + "resultados/ejercicio1");
		
	}
	
	

}
