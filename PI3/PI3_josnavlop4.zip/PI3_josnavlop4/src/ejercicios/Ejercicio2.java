package ejercicios;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.alg.shortestpath.FloydWarshallShortestPaths;
import org.jgrapht.alg.tour.HeldKarpTSP;
import datos.Ciudad;
import datos.Transporte;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.views.SubGraphView;

public class Ejercicio2 {
	
//	APARTADO A
	public static void ApartadoA (Graph<Ciudad,Transporte> g, String file) {
		
		ConnectivityInspector<Ciudad, Transporte> conIns= new ConnectivityInspector<>(g);
		List<Set<Ciudad>> conComps = conIns.connectedSets();

		GraphColors.toDot(g,
						"resultados/ejercicio2/" + file + "_ApartadoA.gv",
						v -> v.ciudad(),
						e -> "",
						v -> GraphColors.color(asignaColor(v,conComps,conIns)),
						e -> GraphColors.color(asignaColor(g.getEdgeSource(e), conComps, conIns)));
		
		
		System.out.println(file + "_ApartadoA.gv generado en resultados/ejercicio2");
				
	}
	
	private static Color asignaColor(Ciudad v, List<Set<Ciudad>> ls, ConnectivityInspector<Ciudad, Transporte> alg) {
		Color[] vc = Color.values(); //Una lista de colores
		Set<Ciudad> s = alg.connectedSetOf(v); //La componente conexa a la que pertenece el vértice
		return vc[ls.indexOf(s)]; //Qué componente conexa es dentro de la lista
	}
	
//	APARTADO B
	
	public static void ApartadoB (Graph<Ciudad,Transporte> g, String file) {
		
		ConnectivityInspector<Ciudad, Transporte> conIns= new ConnectivityInspector<>(g);
		List<Set<Ciudad>> conComps = conIns.connectedSets();
		
		Set<Ciudad> c1 = conComps.get(0);
		Set<Ciudad> c2 = conComps.get(1);
		
		Graph<Ciudad,Transporte> g1 = grafoConexo(g,c1); 
		Graph<Ciudad,Transporte> g2 = grafoConexo(g,c2); 
		
		List<Ciudad> vertices1 = g1.vertexSet().stream().toList();
		List<Ciudad> vertices2 = g2.vertexSet().stream().toList();
		
		List<Transporte> aristas1 = g1.edgeSet().stream().toList();
		List<Transporte> aristas2 = g2.edgeSet().stream().toList();
		
		Double suma1 = vertices1.stream().mapToDouble(x->x.puntuacion()).sum();
		Double suma2 = vertices2.stream().mapToDouble(x->x.puntuacion()).sum();
		
		if(suma1>suma2) {
		
			GraphColors.toDot(g,
					"resultados/ejercicio2/" + file + "_ApartadoB.gv",
					v->v.ciudad(),
					v->v.precio().toString(),
					v -> GraphColors.colorIf(Color.blue,vertices1.contains(v)),
					e -> GraphColors.colorIf(Color.blue,aristas1.contains(e)));

			System.out.println(file + "_ApartadoB.gv generado en resultados/ejercicio2");
			
		} else {
			
			GraphColors.toDot(g,
					"resultados/ejercicio2/" + file + "_ApartadoB.gv",
					v->v.ciudad(),
					v->v.precio().toString(),
					v -> GraphColors.colorIf(Color.blue,vertices2.contains(v)),
					e -> GraphColors.colorIf(Color.blue,aristas2.contains(e)));

			System.out.println(file + "_ApartadoB.gv generado en resultados/ejercicio2");
			
		}
		
		
	}
	
//	APARTADO C
	
	public static void ApartadoC (Graph<Ciudad,Transporte> g, String file) {
		
		ConnectivityInspector<Ciudad, Transporte> conIns= new ConnectivityInspector<>(g);
		List<Set<Ciudad>> conComps = conIns.connectedSets();
		
		Set<Ciudad> c1 = conComps.get(0);
		Set<Ciudad> c2 = conComps.get(1);
		
		Graph<Ciudad,Transporte> g1 = grafoConexo(g,c1); 
		Graph<Ciudad,Transporte> g2 = grafoConexo(g,c2); 
		
		List<Ciudad> lc1 = new HeldKarpTSP<Ciudad,Transporte>().getTour(g1).getVertexList();
		List<Transporte> lt1= new HeldKarpTSP<Ciudad,Transporte>().getTour(g1).getEdgeList();
		
		List<Ciudad> lc2 = new HeldKarpTSP<Ciudad,Transporte>().getTour(g2).getVertexList();
		List<Transporte> lt2= new HeldKarpTSP<Ciudad,Transporte>().getTour(g2).getEdgeList();
		
		lc1.addAll(lc2);
		lt1.addAll(lt2);
		
		GraphColors.toDot(g,
				"resultados/ejercicio2/" + file + "_ApartadoC.gv",
				v->v.ciudad(),
				v->v.precio().toString(),
				v -> GraphColors.colorIf(Color.blue,lc1.contains(v)),
				e -> GraphColors.colorIf(Color.blue,lt1.contains(e)));

		System.out.println(file + "_ApartadoC.gv generado en resultados/ejercicio2");
		
	}
	
	public static Graph<Ciudad,Transporte> grafoConexo (Graph<Ciudad,Transporte> g, Set<Ciudad> g1){
		return SubGraphView.of(g,x->g1.contains(x),null);
	}
	
//	APARTADO D
	
	public static void ApartadoD (Graph<Ciudad,Transporte> g, String file) {
		
		ConnectivityInspector<Ciudad, Transporte> conIns= new ConnectivityInspector<>(g);
		List<Set<Ciudad>> conComps = conIns.connectedSets();
		
		Set<Ciudad> c1 = conComps.get(0);
		Set<Ciudad> c2 = conComps.get(1);
		
		Graph<Ciudad,Transporte> g1 = grafoConexo(g,c1); 
		Graph<Ciudad,Transporte> g2 = grafoConexo(g,c2); 
		
		List<Ciudad> vertices1 = g1.vertexSet().stream().toList();
		List<Ciudad> vertices2 = g2.vertexSet().stream().toList();
		
		Set<GraphPath<Ciudad,Transporte>> sg1 = floyd(g1,vertices1);
		Set<GraphPath<Ciudad,Transporte>> sg2 = floyd(g2,vertices2);
		
		GraphPath<Ciudad,Transporte> q1 = minimo(sg1);
		GraphPath<Ciudad,Transporte> q2 = minimo(sg2);
		
		List<Ciudad> lc1 = q1.getVertexList();
		List<Transporte> lt1 = q1.getEdgeList();
		
		List<Ciudad> lc2 = q2.getVertexList();
		List<Transporte> lt2 = q2.getEdgeList();
		
		lc1.addAll(lc2);
		lt1.addAll(lt2);
		
		GraphColors.toDot(g,
				"resultados/ejercicio2/" + file + "_ApartadoD.gv",
				c -> c.ciudad().toString(),	
				e -> e.duracion().toString(),
				v -> GraphColors.colorIf(Color.blue, lc1.contains(v)),
				e -> GraphColors.colorIf(Color.blue, lt1.contains(e)));
		
		System.out.println(file + "_ApartadoD.gv generado en resultados/ejercicio2");
		
	}
	
	public static GraphPath<Ciudad,Transporte> minimo (Set<GraphPath<Ciudad,Transporte>> sg){
		return sg.stream().filter(x->x.getLength()>=2).min(Comparator.comparing(x->x.getWeight())).get();
	}
	
	public static Set<GraphPath<Ciudad,Transporte>> floyd (Graph<Ciudad,Transporte> g, List<Ciudad> vertices){
		
		FloydWarshallShortestPaths<Ciudad, Transporte> a  = new FloydWarshallShortestPaths<>(g);
		Set<GraphPath<Ciudad,Transporte>> s = new HashSet<>();
		
		for(int i = 0;i<vertices.size();i++) {
			for(int j = i+1;j<vertices.size();j++) {
				s.add(a.getPath(vertices.get(i), vertices.get(j)));
			}
		}
		
		return s;
		
	}
}
