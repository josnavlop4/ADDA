package ejercicios;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.alg.color.GreedyColoring;
import org.jgrapht.alg.interfaces.VertexColoringAlgorithm.Coloring;
import org.jgrapht.graph.DefaultEdge;

import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Style;

public class Ejercicio3 {

	public static void todosLosApartados(Graph<String, DefaultEdge> g,String file) {
		
		GreedyColoring<String,DefaultEdge> gColoring = new GreedyColoring<>(g);
		Coloring<String> coloring = gColoring.getColoring();
		
		List<Set<String>> composicion = coloring.getColorClasses();
		System.out.println(String.format("Nº de franjas necesarias: ",composicion.size()));
		
		for(int i=0;i<composicion.size();i++) {
			System.out.println(String.format("Franja nº %d: %s", i, composicion.get(i)));
			
		}
		
		Map<String, Integer> map = coloring.getColors();
		
		GraphColors.toDot(g,
						"resultados/ejercicio3/" + file + "_ApartadoAyB.gv",
						v -> v.toString(),
						e -> "",
						v -> GraphColors.color(map.get(v)),
						e -> GraphColors.style(Style.solid));
		
		System.out.println(file + "_ApartadoAyB.gv generado en resultados/ejercicio3");
		
	}
	
	

}
